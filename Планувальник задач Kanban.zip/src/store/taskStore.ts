/**
 * Zustand store for task management
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Task, Label, Project, Filter, TaskPriority, TaskStatus } from '../types/task';

interface TaskStore {
  // State
  tasks: Task[];
  labels: Label[];
  projects: Project[];
  filter: Filter;
  selectedProjectId: string | null;
  
  // Actions
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskComplete: (id: string) => void;
  
  // Labels
  addLabel: (label: Omit<Label, 'id'>) => void;
  updateLabel: (id: string, updates: Partial<Label>) => void;
  deleteLabel: (id: string) => void;
  
  // Projects
  addProject: (project: Omit<Project, 'id' | 'createdAt'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  setSelectedProject: (id: string | null) => void;
  
  // Filters
  setFilter: (filter: Partial<Filter>) => void;
  clearFilter: () => void;
  
  // Getters
  getTaskById: (id: string) => Task | undefined;
  getSubtasks: (parentId: string) => Task[];
  getFilteredTasks: () => Task[];
}

const generateId = () => Math.random().toString(36).substr(2, 9);

export const useTaskStore = create<TaskStore>()(
  persist(
    (set, get) => ({
      // Initial state
      tasks: [],
      labels: [
        { id: '1', name: 'Work', color: '#3B82F6' },
        { id: '2', name: 'Personal', color: '#10B981' },
        { id: '3', name: 'Important', color: '#EF4444' },
      ],
      projects: [
        { id: '1', name: 'Inbox', color: '#6B7280', taskIds: [], createdAt: new Date() },
      ],
      filter: {},
      selectedProjectId: '1',

      // Task actions
      addTask: (taskData) => {
        const task: Task = {
          ...taskData,
          id: generateId(),
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        
        set((state) => ({
          tasks: [...state.tasks, task],
        }));
      },

      updateTask: (id, updates) => {
        set((state) => ({
          tasks: state.tasks.map((task) =>
            task.id === id
              ? { ...task, ...updates, updatedAt: new Date() }
              : task
          ),
        }));
      },

      deleteTask: (id) => {
        set((state) => ({
          tasks: state.tasks.filter((task) => task.id !== id && task.parentId !== id),
        }));
      },

      toggleTaskComplete: (id) => {
        const task = get().getTaskById(id);
        if (!task) return;

        const updates: Partial<Task> = {
          isCompleted: !task.isCompleted,
          status: !task.isCompleted ? 'completed' : 'todo',
          completedAt: !task.isCompleted ? new Date() : undefined,
        };

        get().updateTask(id, updates);
      },

      // Label actions
      addLabel: (labelData) => {
        const label: Label = {
          ...labelData,
          id: generateId(),
        };
        
        set((state) => ({
          labels: [...state.labels, label],
        }));
      },

      updateLabel: (id, updates) => {
        set((state) => ({
          labels: state.labels.map((label) =>
            label.id === id ? { ...label, ...updates } : label
          ),
        }));
      },

      deleteLabel: (id) => {
        set((state) => ({
          labels: state.labels.filter((label) => label.id !== id),
          tasks: state.tasks.map((task) => ({
            ...task,
            labels: task.labels.filter((label) => label.id !== id),
          })),
        }));
      },

      // Project actions
      addProject: (projectData) => {
        const project: Project = {
          ...projectData,
          id: generateId(),
          createdAt: new Date(),
        };
        
        set((state) => ({
          projects: [...state.projects, project],
        }));
      },

      updateProject: (id, updates) => {
        set((state) => ({
          projects: state.projects.map((project) =>
            project.id === id ? { ...project, ...updates } : project
          ),
        }));
      },

      deleteProject: (id) => {
        set((state) => ({
          projects: state.projects.filter((project) => project.id !== id),
          selectedProjectId: state.selectedProjectId === id ? '1' : state.selectedProjectId,
        }));
      },

      setSelectedProject: (id) => {
        set({ selectedProjectId: id });
      },

      // Filter actions
      setFilter: (newFilter) => {
        set((state) => ({
          filter: { ...state.filter, ...newFilter },
        }));
      },

      clearFilter: () => {
        set({ filter: {} });
      },

      // Getters
      getTaskById: (id) => {
        return get().tasks.find((task) => task.id === id);
      },

      getSubtasks: (parentId) => {
        return get().tasks.filter((task) => task.parentId === parentId);
      },

      getFilteredTasks: () => {
        const { tasks, filter } = get();
        
        return tasks.filter((task) => {
          // Don't show subtasks in main list
          if (task.parentId) return false;

          // Search filter
          if (filter.search) {
            const searchLower = filter.search.toLowerCase();
            if (!task.title.toLowerCase().includes(searchLower) &&
                !task.description?.toLowerCase().includes(searchLower)) {
              return false;
            }
          }

          // Priority filter
          if (filter.priority?.length && !filter.priority.includes(task.priority)) {
            return false;
          }

          // Status filter
          if (filter.status?.length && !filter.status.includes(task.status)) {
            return false;
          }

          // Labels filter
          if (filter.labels?.length) {
            const taskLabelIds = task.labels.map(l => l.id);
            if (!filter.labels.some(labelId => taskLabelIds.includes(labelId))) {
              return false;
            }
          }

          return true;
        });
      },
    }),
    {
      name: 'task-store',
    }
  )
);
