/**
 * Main application home page with task management interface
 */

import React, { useState, useEffect } from 'react';
import { useTaskStore } from '../store/taskStore';
import { Task, TaskStatus } from '../types/task';
import { Sidebar } from '../components/Sidebar';
import { TaskFilters } from '../components/TaskFilters';
import { TaskForm } from '../components/TaskForm';
import { TaskItem } from '../components/TaskItem';
import { KanbanBoard } from '../components/KanbanBoard';
import { Button } from '../components/ui/button';
import { Plus, List, BarChart3 } from 'lucide-react';

export default function Home() {
  const { getFilteredTasks, tasks } = useTaskStore();
  const [activeView, setActiveView] = useState('inbox');
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>();
  const [defaultStatus, setDefaultStatus] = useState<TaskStatus>('todo');

  // Request notification permissions on load
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  const handleAddTask = (status?: TaskStatus) => {
    setDefaultStatus(status || 'todo');
    setEditingTask(undefined);
    setIsTaskFormOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsTaskFormOpen(true);
  };

  const handleCloseTaskForm = () => {
    setIsTaskFormOpen(false);
    setEditingTask(undefined);
  };

  const getViewTasks = () => {
    const allTasks = getFilteredTasks();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    switch (activeView) {
      case 'today':
        return allTasks.filter(task => {
          if (!task.dueDate) return false;
          const taskDate = new Date(task.dueDate);
          taskDate.setHours(0, 0, 0, 0);
          return taskDate.getTime() === today.getTime();
        });
      
      case 'upcoming':
        return allTasks.filter(task => {
          if (!task.dueDate) return false;
          return task.dueDate < new Date() && !task.isCompleted;
        });
      
      case 'project':
      case 'inbox':
      default:
        return allTasks;
    }
  };

  const getViewTitle = () => {
    switch (activeView) {
      case 'today':
        return 'Today';
      case 'upcoming':
        return 'Overdue Tasks';
      case 'kanban':
        return 'Kanban Board';
      case 'project':
        return 'Project Tasks';
      case 'inbox':
      default:
        return 'All Tasks';
    }
  };

  const viewTasks = getViewTasks();

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <Sidebar activeView={activeView} onViewChange={setActiveView} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">
              {getViewTitle()}
            </h1>
            
            <div className="flex items-center gap-2">
              {activeView !== 'kanban' && (
                <Button
                  variant="outline"
                  onClick={() => setActiveView('kanban')}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Kanban
                </Button>
              )}
              
              {activeView === 'kanban' && (
                <Button
                  variant="outline"
                  onClick={() => setActiveView('inbox')}
                >
                  <List className="h-4 w-4 mr-2" />
                  List View
                </Button>
              )}
              
              <Button onClick={() => handleAddTask()}>
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            </div>
          </div>
        </div>

        {/* Filters */}
        {activeView !== 'kanban' && (
          <div className="bg-white border-b px-6 py-4">
            <TaskFilters />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {activeView === 'kanban' ? (
            <div className="min-h-full">
              <KanbanBoard
                onAddTask={handleAddTask}
                onEditTask={handleEditTask}
              />
            </div>
          ) : (
            <div className="space-y-4">
              {viewTasks.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <List className="h-12 w-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No tasks found
                  </h3>
                  <p className="text-gray-500 mb-4">
                    Get started by creating your first task
                  </p>
                  <Button onClick={() => handleAddTask()}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Task
                  </Button>
                </div>
              ) : (
                viewTasks.map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onEdit={handleEditTask}
                  />
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* Task Form Modal */}
      <TaskForm
        task={editingTask}
        isOpen={isTaskFormOpen}
        onClose={handleCloseTaskForm}
      />
    </div>
  );
}
