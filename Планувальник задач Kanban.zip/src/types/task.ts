/**
 * Types and interfaces for task management system
 */

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'todo' | 'in-progress' | 'completed';

export interface Label {
  id: string;
  name: string;
  color: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
  labels: Label[];
  parentId?: string; // For subtasks
  isCompleted: boolean;
  completedAt?: Date;
}

export interface Project {
  id: string;
  name: string;
  color: string;
  taskIds: string[];
  createdAt: Date;
}

export interface Filter {
  search?: string;
  priority?: TaskPriority[];
  status?: TaskStatus[];
  labels?: string[];
  project?: string;
  dueDate?: 'today' | 'week' | 'overdue' | 'no-date';
}
