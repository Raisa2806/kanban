/**
 * Sidebar navigation component with projects and quick actions
 */

import React from 'react';
import { useTaskStore } from '../store/taskStore';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  CheckSquare, 
  Calendar, 
  Inbox, 
  Star, 
  Plus,
  Settings,
  List,
  BarChart3
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange }) => {
  const { tasks, projects, selectedProjectId, setSelectedProject } = useTaskStore();

  const todayTasks = tasks.filter(task => {
    const today = new Date();
    return task.dueDate && 
           task.dueDate.toDateString() === today.toDateString() && 
           !task.isCompleted;
  });

  const overdueTasks = tasks.filter(task => {
    const today = new Date();
    return task.dueDate && 
           task.dueDate < today && 
           !task.isCompleted;
  });

  const incompleteTasks = tasks.filter(task => !task.isCompleted);

  const menuItems = [
    {
      id: 'inbox',
      label: 'Inbox',
      icon: Inbox,
      count: incompleteTasks.length,
      onClick: () => onViewChange('inbox')
    },
    {
      id: 'today',
      label: 'Today',
      icon: Calendar,
      count: todayTasks.length,
      onClick: () => onViewChange('today')
    },
    {
      id: 'upcoming',
      label: 'Upcoming',
      icon: Star,
      count: overdueTasks.length,
      onClick: () => onViewChange('upcoming')
    },
    {
      id: 'kanban',
      label: 'Kanban Board',
      icon: BarChart3,
      count: 0,
      onClick: () => onViewChange('kanban')
    }
  ];

  return (
    <div className="w-64 bg-gray-50 border-r h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <h1 className="text-xl font-bold text-gray-900 flex items-center">
          <CheckSquare className="h-6 w-6 mr-2 text-blue-600" />
          TaskMaster
        </h1>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={activeView === item.id ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={item.onClick}
            >
              <item.icon className="h-4 w-4 mr-3" />
              <span className="flex-1 text-left">{item.label}</span>
              {item.count > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {item.count}
                </Badge>
              )}
            </Button>
          ))}
        </div>

        {/* Projects Section */}
        <div className="pt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-700">Projects</h3>
            <Button variant="ghost" size="sm">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-1">
            {projects.map((project) => {
              const projectTasks = tasks.filter(task => 
                !task.parentId && !task.isCompleted
              );
              
              return (
                <Button
                  key={project.id}
                  variant={selectedProjectId === project.id ? "secondary" : "ghost"}
                  className="w-full justify-start text-sm"
                  onClick={() => {
                    setSelectedProject(project.id);
                    onViewChange('project');
                  }}
                >
                  <div
                    className="w-3 h-3 rounded-full mr-3"
                    style={{ backgroundColor: project.color }}
                  />
                  <span className="flex-1 text-left">{project.name}</span>
                  {projectTasks.length > 0 && (
                    <Badge variant="outline" className="ml-2 text-xs">
                      {projectTasks.length}
                    </Badge>
                  )}
                </Button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t">
        <Button
          variant="ghost"
          className="w-full justify-start text-sm"
          onClick={() => onViewChange('settings')}
        >
          <Settings className="h-4 w-4 mr-3" />
          Settings
        </Button>
      </div>
    </div>
  );
};
