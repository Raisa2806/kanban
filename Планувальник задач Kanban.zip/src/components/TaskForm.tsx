/**
 * Task creation and editing form component
 */

import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Task, TaskPriority, Label } from '../types/task';
import { useTaskStore } from '../store/taskStore';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label as UILabel } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { CalendarIcon, X } from 'lucide-react';
import { format } from 'date-fns';
import { Checkbox } from './ui/checkbox';

interface TaskFormProps {
  task?: Task;
  isOpen: boolean;
  onClose: () => void;
}

interface FormData {
  title: string;
  description: string;
  priority: TaskPriority;
  dueDate?: Date;
  labelIds: string[];
}

export const TaskForm: React.FC<TaskFormProps> = ({ task, isOpen, onClose }) => {
  const { addTask, updateTask, labels } = useTaskStore();
  const isEditing = !!task;

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      title: '',
      description: '',
      priority: 'medium',
      labelIds: [],
    }
  });

  const watchedValues = watch();

  useEffect(() => {
    if (task) {
      reset({
        title: task.title,
        description: task.description || '',
        priority: task.priority,
        dueDate: task.dueDate,
        labelIds: task.labels.map(l => l.id),
      });
    } else {
      reset({
        title: '',
        description: '',
        priority: 'medium',
        labelIds: [],
      });
    }
  }, [task, reset]);

  const onSubmit = (data: FormData) => {
    const selectedLabels = labels.filter(label => data.labelIds.includes(label.id));

    if (isEditing && task) {
      updateTask(task.id, {
        title: data.title,
        description: data.description,
        priority: data.priority,
        dueDate: data.dueDate,
        labels: selectedLabels,
      });
    } else {
      addTask({
        title: data.title,
        description: data.description,
        priority: data.priority,
        status: 'todo',
        dueDate: data.dueDate,
        labels: selectedLabels,
        isCompleted: false,
      });
    }

    onClose();
    reset();
  };

  const handleLabelToggle = (labelId: string) => {
    const currentLabels = watchedValues.labelIds || [];
    if (currentLabels.includes(labelId)) {
      setValue('labelIds', currentLabels.filter(id => id !== labelId));
    } else {
      setValue('labelIds', [...currentLabels, labelId]);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? 'Edit Task' : 'Create New Task'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <UILabel htmlFor="title">Title</UILabel>
            <Input
              id="title"
              {...register('title', { required: 'Title is required' })}
              placeholder="Enter task title..."
            />
            {errors.title && (
              <p className="text-sm text-red-600 mt-1">{errors.title.message}</p>
            )}
          </div>

          <div>
            <UILabel htmlFor="description">Description</UILabel>
            <Textarea
              id="description"
              {...register('description')}
              placeholder="Enter task description..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <UILabel>Priority</UILabel>
              <Select 
                value={watchedValues.priority} 
                onValueChange={(value) => setValue('priority', value as TaskPriority)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <UILabel>Due Date</UILabel>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {watchedValues.dueDate ? (
                      format(watchedValues.dueDate, 'PPP')
                    ) : (
                      <span>Pick a date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={watchedValues.dueDate}
                    onSelect={(date) => setValue('dueDate', date)}
                    initialFocus
                  />
                  {watchedValues.dueDate && (
                    <div className="p-3 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setValue('dueDate', undefined)}
                        className="w-full"
                      >
                        <X className="mr-2 h-4 w-4" />
                        Clear Date
                      </Button>
                    </div>
                  )}
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div>
            <UILabel>Labels</UILabel>
            <div className="flex flex-wrap gap-2 mt-2">
              {labels.map((label) => (
                <div
                  key={label.id}
                  className="flex items-center space-x-2 p-2 border rounded cursor-pointer hover:bg-gray-50"
                  onClick={() => handleLabelToggle(label.id)}
                >
                  <Checkbox
                    checked={watchedValues.labelIds?.includes(label.id) || false}
                    onChange={() => handleLabelToggle(label.id)}
                  />
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: label.color }}
                  />
                  <span className="text-sm">{label.name}</span>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {isEditing ? 'Update Task' : 'Create Task'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
