/**
 * Kanban board component for task management
 */

import React, { useState } from 'react';
import { Task, TaskStatus } from '../types/task';
import { useTaskStore } from '../store/taskStore';
import { TaskItem } from './TaskItem';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Plus } from 'lucide-react';

interface KanbanColumnProps {
  title: string;
  status: TaskStatus;
  tasks: Task[];
  onAddTask: (status: TaskStatus) => void;
  onEditTask: (task: Task) => void;
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({ 
  title, 
  status, 
  tasks, 
  onAddTask, 
  onEditTask 
}) => {
  const { updateTask } = useTaskStore();

  const handleDrop = React.useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    if (taskId) {
      updateTask(taskId, { status });
    }
  }, [updateTask, status]);

  const handleDragOver = React.useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const statusColors: Record<TaskStatus, string> = {
    'todo': 'border-gray-200 bg-gray-50',
    'in-progress': 'border-blue-200 bg-blue-50',
    'completed': 'border-green-200 bg-green-50',
  };

  return (
    <Card 
      className={`flex-1 min-h-[500px] min-w-[300px] ${statusColors[status]}`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            {title}
            <span className="ml-2 text-sm font-normal text-gray-500">
              ({tasks?.length || 0})
            </span>
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onAddTask(status)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {tasks && tasks.length > 0 ? (
          tasks.map((task) => (
            <div
              key={task.id}
              draggable
              onDragStart={(e) => {
                e.dataTransfer.setData('text/plain', task.id);
              }}
              className="cursor-move"
            >
              <TaskItem
                task={task}
                onEdit={onEditTask}
              />
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">No tasks in {title.toLowerCase()}</p>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onAddTask(status)}
              className="mt-2"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add task
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

interface KanbanBoardProps {
  onAddTask: (status?: TaskStatus) => void;
  onEditTask: (task: Task) => void;
}

export const KanbanBoard: React.FC<KanbanBoardProps> = ({ onAddTask, onEditTask }) => {
  const { getFilteredTasks } = useTaskStore();
  
  // Безпечна фільтрація задач
  const tasks = React.useMemo(() => {
    try {
      return getFilteredTasks() || [];
    } catch (error) {
      console.error('Error filtering tasks:', error);
      return [];
    }
  }, [getFilteredTasks]);

  const todoTasks = tasks.filter(task => task.status === 'todo');
  const inProgressTasks = tasks.filter(task => task.status === 'in-progress');
  const completedTasks = tasks.filter(task => task.status === 'completed');

  return (
    <div className="space-y-6 min-h-screen">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Kanban Board</h2>
        <Button onClick={() => onAddTask()}>
          <Plus className="h-4 w-4 mr-2" />
          Add Task
        </Button>
      </div>

      <div className="flex gap-6 overflow-x-auto pb-4 min-h-[600px]">
        <KanbanColumn
          title="To Do"
          status="todo"
          tasks={todoTasks}
          onAddTask={onAddTask}
          onEditTask={onEditTask}
        />
        
        <KanbanColumn
          title="In Progress"
          status="in-progress"
          tasks={inProgressTasks}
          onAddTask={onAddTask}
          onEditTask={onEditTask}
        />
        
        <KanbanColumn
          title="Completed"
          status="completed"
          tasks={completedTasks}
          onAddTask={onAddTask}
          onEditTask={onEditTask}
        />
      </div>
    </div>
  );
};
