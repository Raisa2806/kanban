/**
 * Individual task item component with complete/edit functionality
 */

import React, { useState } from 'react';
import { Task, TaskPriority } from '../types/task';
import { useTaskStore } from '../store/taskStore';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { 
  Calendar, 
  ChevronDown, 
  ChevronRight, 
  Edit, 
  MoreHorizontal, 
  Plus, 
  Trash 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { format } from 'date-fns';

interface TaskItemProps {
  task: Task;
  onEdit: (task: Task) => void;
  className?: string;
}

const priorityColors: Record<TaskPriority, string> = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-yellow-100 text-yellow-800',
  urgent: 'bg-red-100 text-red-800',
};

const priorityBorderColors: Record<TaskPriority, string> = {
  low: 'border-l-gray-400',
  medium: 'border-l-blue-400', 
  high: 'border-l-yellow-400',
  urgent: 'border-l-red-400',
};

export const TaskItem: React.FC<TaskItemProps> = ({ task, onEdit, className = '' }) => {
  const { toggleTaskComplete, deleteTask, getSubtasks, addTask } = useTaskStore();
  const [showSubtasks, setShowSubtasks] = useState(false);
  const subtasks = getSubtasks(task.id);

  const handleToggleComplete = () => {
    toggleTaskComplete(task.id);
  };

  const handleDelete = () => {
    deleteTask(task.id);
  };

  const handleAddSubtask = () => {
    const title = prompt('Enter subtask title:');
    if (title?.trim()) {
      addTask({
        title: title.trim(),
        priority: 'medium',
        status: 'todo',
        labels: [],
        parentId: task.id,
        isCompleted: false,
      });
    }
  };

  const isOverdue = task.dueDate && task.dueDate < new Date() && !task.isCompleted;

  return (
    <div className={`${className}`}>
      <div
        className={`group p-4 border rounded-lg bg-white hover:shadow-md transition-shadow border-l-4 ${
          priorityBorderColors[task.priority]
        } ${task.isCompleted ? 'opacity-60' : ''}`}
      >
        <div className="flex items-start gap-3">
          <Checkbox
            checked={task.isCompleted}
            onCheckedChange={handleToggleComplete}
            className="mt-1"
          />
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3
                className={`font-medium text-gray-900 ${
                  task.isCompleted ? 'line-through text-gray-500' : ''
                }`}
              >
                {task.title}
              </h3>
              
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEdit(task)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={handleAddSubtask}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Subtask
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={handleDelete}
                      className="text-red-600"
                    >
                      <Trash className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {task.description && (
              <p className="text-sm text-gray-600 mt-1">{task.description}</p>
            )}

            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge 
                variant="secondary" 
                className={priorityColors[task.priority]}
              >
                {task.priority}
              </Badge>

              {task.labels.map((label) => (
                <Badge
                  key={label.id}
                  style={{ backgroundColor: label.color + '20', color: label.color }}
                  className="border-0"
                >
                  {label.name}
                </Badge>
              ))}

              {task.dueDate && (
                <div className={`flex items-center gap-1 text-sm ${
                  isOverdue ? 'text-red-600' : 'text-gray-500'
                }`}>
                  <Calendar className="h-3 w-3" />
                  <span>{format(task.dueDate, 'MMM dd')}</span>
                </div>
              )}
            </div>
          </div>

          {subtasks.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSubtasks(!showSubtasks)}
            >
              {showSubtasks ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Subtasks */}
      {showSubtasks && subtasks.length > 0 && (
        <div className="ml-8 mt-2 space-y-2">
          {subtasks.map((subtask) => (
            <TaskItem
              key={subtask.id}
              task={subtask}
              onEdit={onEdit}
              className="scale-95"
            />
          ))}
        </div>
      )}
    </div>
  );
};
