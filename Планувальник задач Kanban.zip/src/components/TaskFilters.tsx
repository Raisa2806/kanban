/**
 * Task filtering and search component
 */

import React from 'react';
import { useTaskStore } from '../store/taskStore';
import { TaskPriority, TaskStatus } from '../types/task';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { Checkbox } from './ui/checkbox';
import { Search, Filter, X } from 'lucide-react';

export const TaskFilters: React.FC = () => {
  const { filter, setFilter, clearFilter, labels } = useTaskStore();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilter({ search: e.target.value });
  };

  const handlePriorityToggle = (priority: TaskPriority) => {
    const currentPriorities = filter.priority || [];
    if (currentPriorities.includes(priority)) {
      setFilter({
        priority: currentPriorities.filter(p => p !== priority)
      });
    } else {
      setFilter({
        priority: [...currentPriorities, priority]
      });
    }
  };

  const handleStatusToggle = (status: TaskStatus) => {
    const currentStatuses = filter.status || [];
    if (currentStatuses.includes(status)) {
      setFilter({
        status: currentStatuses.filter(s => s !== status)
      });
    } else {
      setFilter({
        status: [...currentStatuses, status]
      });
    }
  };

  const handleLabelToggle = (labelId: string) => {
    const currentLabels = filter.labels || [];
    if (currentLabels.includes(labelId)) {
      setFilter({
        labels: currentLabels.filter(id => id !== labelId)
      });
    } else {
      setFilter({
        labels: [...currentLabels, labelId]
      });
    }
  };

  const activeFiltersCount = 
    (filter.priority?.length || 0) +
    (filter.status?.length || 0) +
    (filter.labels?.length || 0) +
    (filter.dueDate ? 1 : 0);

  return (
    <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search tasks..."
          value={filter.search || ''}
          onChange={handleSearchChange}
          className="pl-10"
        />
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {/* Priority Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Priority
              {filter.priority?.length && (
                <Badge variant="secondary" className="ml-2">
                  {filter.priority.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Filter by Priority</h4>
              {(['low', 'medium', 'high', 'urgent'] as TaskPriority[]).map((priority) => (
                <div
                  key={priority}
                  className="flex items-center space-x-2 cursor-pointer"
                  onClick={() => handlePriorityToggle(priority)}
                >
                  <Checkbox
                    checked={filter.priority?.includes(priority) || false}
                  />
                  <span className="capitalize text-sm">{priority}</span>
                </div>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Status Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm">
              Status
              {filter.status?.length && (
                <Badge variant="secondary" className="ml-2">
                  {filter.status.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Filter by Status</h4>
              {(['todo', 'in-progress', 'completed'] as TaskStatus[]).map((status) => (
                <div
                  key={status}
                  className="flex items-center space-x-2 cursor-pointer"
                  onClick={() => handleStatusToggle(status)}
                >
                  <Checkbox
                    checked={filter.status?.includes(status) || false}
                  />
                  <span className="capitalize text-sm">{status.replace('-', ' ')}</span>
                </div>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Labels Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm">
              Labels
              {filter.labels?.length && (
                <Badge variant="secondary" className="ml-2">
                  {filter.labels.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-56">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Filter by Labels</h4>
              {labels.map((label) => (
                <div
                  key={label.id}
                  className="flex items-center space-x-2 cursor-pointer"
                  onClick={() => handleLabelToggle(label.id)}
                >
                  <Checkbox
                    checked={filter.labels?.includes(label.id) || false}
                  />
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: label.color }}
                  />
                  <span className="text-sm">{label.name}</span>
                </div>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Due Date Filter */}
        <Select
          value={filter.dueDate || 'all'}
          onValueChange={(value) => setFilter({ dueDate: value === 'all' ? undefined : value as any })}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Due date" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All dates</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This week</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
            <SelectItem value="no-date">No date</SelectItem>
          </SelectContent>
        </Select>

        {/* Clear Filters */}
        {activeFiltersCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilter}
            className="text-red-600 hover:text-red-700"
          >
            <X className="h-4 w-4 mr-2" />
            Clear ({activeFiltersCount})
          </Button>
        )}
      </div>
    </div>
  );
};
